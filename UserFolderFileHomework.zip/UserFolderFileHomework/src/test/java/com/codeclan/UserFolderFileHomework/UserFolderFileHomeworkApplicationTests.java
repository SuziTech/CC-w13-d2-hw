package com.codeclan.UserFolderFileHomework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserFolderFileHomeworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
