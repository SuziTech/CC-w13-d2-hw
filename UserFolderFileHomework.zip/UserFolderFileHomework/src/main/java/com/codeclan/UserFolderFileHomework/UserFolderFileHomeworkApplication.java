package com.codeclan.UserFolderFileHomework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserFolderFileHomeworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserFolderFileHomeworkApplication.class, args);
	}

}
